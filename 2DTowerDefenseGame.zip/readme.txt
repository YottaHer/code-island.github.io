Steps to run the game:

Run from the "TheGame" package 
1- create map from the map drop-down menu
2- Define Entry and Exit points and path
3- save the map(example : map1)
4- from the menu start a game 
5- choose the map (example : the map1)
6- Place towers near the path
7- start a new wave (the highest level is three)


